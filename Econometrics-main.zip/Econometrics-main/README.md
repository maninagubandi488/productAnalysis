# Econometrics

### Panel Data Models
* What is panel data? and how is it different from a time series data?
* Different panel data model types
* Let's program it in R
